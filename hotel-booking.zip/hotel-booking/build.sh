#!/bin/bash
# Compiles all Java files into WebContent/WEB-INF/classes
# Usage: ./build.sh

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
TOMCAT_LIB="/opt/tomcat9/lib"
SRC="$PROJECT_DIR/src"
OUT="$PROJECT_DIR/WebContent/WEB-INF/classes"
WEBLIB="$PROJECT_DIR/WebContent/WEB-INF/lib"

MYSQL_JAR="$WEBLIB/$(ls "$WEBLIB" 2>/dev/null | grep -i mysql | head -1)"

echo "Creating classes directory..."
mkdir -p "$OUT"

CP="$TOMCAT_LIB/servlet-api.jar:$TOMCAT_LIB/jsp-api.jar"
if [ -n "$MYSQL_JAR" ]; then
    CP="$CP:$MYSQL_JAR"
else
    echo "WARNING: no mysql-connector jar found in WEB-INF/lib. Download it first:"
    echo "  ./setup-connector.sh"
fi

echo "Compiling..."
find "$SRC" -name "*.java" | xargs javac -cp "$CP" -d "$OUT"

echo "Done. Classes output to: $OUT"