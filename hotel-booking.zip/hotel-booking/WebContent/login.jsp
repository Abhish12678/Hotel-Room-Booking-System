<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Login - Grand Hotel</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <div class="brand">Grand Hotel</div>
        <div>
            <a href="index.jsp">Home</a>
            <a href="register.jsp">Register</a>
        </div>
    </nav>
    <div class="card">
        <h2>Login</h2>
        <% if (request.getAttribute("error") != null) { %>
            <p class="error"><%= request.getAttribute("error") %></p>
        <% } %>
        <form action="login" method="post">
            <label>Email</label>
            <input type="email" name="email" required>

            <label>Password</label>
            <input type="password" name="password" required>

            <button type="submit" class="btn">Login</button>
        </form>
        <p>New here? <a href="register.jsp">Create an account</a></p>
    </div>
</body>
</html>