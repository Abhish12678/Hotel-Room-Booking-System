<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Grand Hotel - Home</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <div class="brand">Grand Hotel</div>
        <div>
            <a href="index.jsp">Home</a>
            <a href="rooms">Rooms</a>
            <a href="login.jsp">Login</a>
            <a href="register.jsp">Register</a>
        </div>
    </nav>
    <div class="hero">
        <h1>Welcome to Grand Hotel</h1>
        <p>Book your stay online in seconds. Choose from Single, Deluxe and Suite rooms.</p>
        <a class="btn" href="register.jsp">Get Started</a>
    </div>
</body>
</html>