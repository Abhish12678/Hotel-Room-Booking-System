<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.hotel.model.Room" %>
<!DOCTYPE html>
<html>
<head>
    <title>Booking Confirmed - Grand Hotel</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <div class="brand">Grand Hotel</div>
        <div>
            <a href="rooms">Rooms</a>
            <a href="myBookings">My Bookings</a>
            <a href="logout">Logout</a>
        </div>
    </nav>
    <div class="card">
        <h2 class="success">Booking Confirmed!</h2>
        <p>Booking ID: <strong><%= request.getAttribute("bookingId") %></strong></p>
        <p>Room <%= ((Room) request.getAttribute("room")).getRoomNumber() %> (<%= ((Room) request.getAttribute("room")).getRoomType() %>)</p>
        <p>Check-in: <%= request.getAttribute("checkIn") %> &nbsp; Check-out: <%= request.getAttribute("checkOut") %></p>
        <p>Guests: <%= request.getAttribute("guests") %></p>
        <p>Total Amount: <strong>Rs.<%= request.getAttribute("total") %></strong></p>
        <p>Paid via: <%= request.getAttribute("paymentMethod") %></p>
        <a class="btn" href="myBookings">View My Bookings</a>
    </div>
</body>
</html>