<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List, com.hotel.model.Booking" %>
<!DOCTYPE html>
<html>
<head>
    <title>My Bookings - Grand Hotel</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <div class="brand">Grand Hotel</div>
        <div>
            <a href="rooms">Rooms</a>
            <a href="logout">Logout</a>
        </div>
    </nav>
    <div class="container">
        <h2>My Bookings</h2>
        <% List<Booking> bookings = (List<Booking>) request.getAttribute("bookings");
           if (bookings == null || bookings.isEmpty()) { %>
            <p>You have no bookings yet. <a href="rooms">Book a room</a></p>
        <% } else {
               for (Booking b : bookings) { %>
                <div class="room-card">
                    <p><strong>Booking #<%= b.getBookingId() %></strong></p>
                    <p>Room <%= b.getRoomNumber() %> (<%= b.getRoomType() %>)</p>
                    <p><%= b.getCheckIn() %> → <%= b.getCheckOut() %> | <%= b.getGuests() %> guest(s)</p>
                    <p>Total: Rs.<%= b.getTotalAmount() %> | Status: <span class="badge"><%= b.getBookingStatus() %></span></p>
                </div>
        <%     }
           } %>
    </div>
</body>
</html>