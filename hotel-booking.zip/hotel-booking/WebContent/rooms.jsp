<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List, com.hotel.model.Room, com.hotel.model.User" %>
<!DOCTYPE html>
<html>
<head>
    <title>Rooms - Grand Hotel</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <div class="brand">Grand Hotel</div>
        <div>
            <a href="index.jsp">Home</a>
            <a href="rooms">Rooms</a>
            <% User sessionUser = (User) session.getAttribute("user");
               if (sessionUser != null) { %>
                <span style="color:#fff">Hi, <%= sessionUser.getName() %></span>
                <a href="myBookings">My Bookings</a>
                <a href="logout">Logout</a>
            <% } else { %>
                <a href="login.jsp">Login</a>
            <% } %>
        </div>
    </nav>
    <div class="container">
        <h2>Available Rooms</h2>
        <% if (request.getAttribute("rooms") != null) {
               List<Room> rooms = (List<Room>) request.getAttribute("rooms");
               for (Room room : rooms) { %>
                <div class="room-card">
                    <h3>Room <%= room.getRoomNumber() %> - <%= room.getRoomType() %></h3>
                    <p><%= room.getDescription() %></p>
                    <p><strong>Rs.<%= room.getPricePerNight() %> / night</strong> | Capacity: <%= room.getCapacity() %> guests</p>
                    <% if ("booked".equals(room.getStatus())) { %>
                        <span class="badge">Already booked</span>
                    <% } else if (sessionUser != null) { %>
                        <a class="btn" href="book?roomId=<%= room.getRoomId() %>">Book Now</a>
                    <% } else { %>
                        <a class="btn" href="login.jsp">Login to Book</a>
                    <% } %>
                </div>
        <%     }
           } else { %>
            <p>No rooms found.</p>
        <% } %>
    </div>
</body>
</html>