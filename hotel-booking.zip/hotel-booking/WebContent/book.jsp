<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="com.hotel.model.Room, com.hotel.model.User" %>
<!DOCTYPE html>
<html>
<head>
    <title>Book Room - Grand Hotel</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav>
        <div class="brand">Grand Hotel</div>
        <div>
            <a href="index.jsp">Home</a>
            <a href="rooms">Rooms</a>
            <a href="myBookings">My Bookings</a>
            <a href="logout">Logout</a>
        </div>
    </nav>
    <div class="card">
        <h2>Book Room <%= ((Room) request.getAttribute("room")).getRoomNumber() %></h2>
        <p><%= ((Room) request.getAttribute("room")).getRoomType() %> - Rs.<%= ((Room) request.getAttribute("room")).getPricePerNight() %> / night</p>

        <% if (request.getAttribute("error") != null) { %>
            <p class="error"><%= request.getAttribute("error") %></p>
        <% } %>

        <form action="processBooking" method="post">
            <input type="hidden" name="roomId" value="<%= ((Room) request.getAttribute("room")).getRoomId() %>">

            <label>Check-in Date</label>
            <input type="date" name="checkIn" required>

            <label>Check-out Date</label>
            <input type="date" name="checkOut" required>

            <label>Guests</label>
            <input type="number" name="guests" min="1" max="<%= ((Room) request.getAttribute("room")).getCapacity() %>" value="1" required>

            <label>Payment Method</label>
            <select name="paymentMethod">
                <option value="card">Credit / Debit Card</option>
                <option value="upi">UPI</option>
                <option value="cash">Cash at Hotel</option>
            </select>

            <button type="submit" class="btn">Confirm Booking</button>
        </form>
    </div>
</body>
</html>