# Hotel Room Booking System (Java Servlets + JSP + MySQL)

A simple 3-tier web app for a 2nd-year engineering project.

```
Browser (JSP/HTML/CSS)
        ↓
Java Servlets  →  DAO classes  →  JDBC
                                  ↓
                               MySQL
```

## Folder structure

```
hotel-booking/
├── database/hotel_booking.sql   # full DB (tables + 5 sample rooms)
├── src/com/hotel/
│   ├── util/DBUtil.java         # JDBC connection (edit user/password here)
│   ├── model/                   # User, Room, Booking
│   ├── dao/                     # UserDAO, RoomDAO, BookingDAO (SQL queries)
│   └── servlet/                 # Register, Login, Logout, Rooms, Book, ProcessBooking, MyBookings
├── WebContent/                  # all JSP pages + CSS
│   ├── WEB-INF/web.xml
│   └── WEB-INF/lib/mysql-connector-j-8.4.0.jar  (downloaded by setup-connector.sh)
├── setup-connector.sh           # downloads JDBC driver (already done)
├── build.sh                     # compiles Java → WebContent/WEB-INF/classes
└── deploy.sh                    # builds + copies to Tomcat webapps
```

## Step 1 — Create the database (run ONCE)

```bash
mysql -u root -p < database/hotel_booking.sql
# enter your MySQL password when prompted
```

## Step 2 — Set your MySQL password in DBUtil.java

Edit `src/com/hotel/util/DBUtil.java`:

```java
private static final String USER = "root";
private static final String PASSWORD = "root";   // <- put your real MySQL password
```

## Step 3 — Build and deploy

```bash
./build.sh                       # compiles the Java classes
sudo ./deploy.sh                 # copies app to /opt/tomcat9/webapps and starts Tomcat
```

## Step 4 — Use it

Open http://localhost:8080/hotel-booking

1. Register as a new user
2. Browse rooms
3. Book a room (pick dates + payment method)
4. See your bookings under "My Bookings"

## Handy database commands

```sql
USE hotel_booking;
SELECT * FROM rooms;
SELECT b.booking_id, u.name, r.room_number, b.check_in, b.check_out, b.total_amount, b.booking_status
FROM bookings b JOIN users u ON b.user_id = u.user_id
JOIN rooms r ON b.room_id = r.room_id;
```

## Needed on your machine

- Java JDK 8+        (found: 25)
- Apache Tomcat 9    (found: /opt/tomcat9)
- MySQL              (found: 8.4)