#!/bin/bash
# Deploys the project to Tomcat. Usage: sudo ./deploy.sh
# (Tomcat webapps dir usually needs root permissions.)

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
WEBAPPS="/opt/tomcat9/webapps"

echo "Building first..."
"$PROJECT_DIR/build.sh" || exit 1

echo "Stopping Tomcat..."
sh /opt/tomcat9/bin/shutdown.sh 2>/dev/null || true

echo "Copying webapp to $WEBAPPS/hotel-booking ..."
cp -r "$PROJECT_DIR/WebContent" "$WEBAPPS/hotel-booking"

echo "Starting Tomcat..."
sudo /opt/tomcat9/bin/startup.sh
echo "Done. Open:  http://localhost:8080/hotel-booking"