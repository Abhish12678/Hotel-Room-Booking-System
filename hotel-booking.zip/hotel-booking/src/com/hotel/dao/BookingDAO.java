package com.hotel.dao;

import com.hotel.model.Booking;
import com.hotel.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class BookingDAO {

    // Create a booking inside a transaction with the payment record.
    // Returns the new booking_id, or -1 on failure.
    public int createBooking(Booking booking, String paymentMethod) {
        String insertBooking = "INSERT INTO bookings (user_id, room_id, check_in, check_out, guests, total_amount) VALUES (?, ?, ?, ?, ?, ?)";
        String insertPayment = "INSERT INTO payments (booking_id, amount, payment_method, payment_status) VALUES (?, ?, ?, 'paid')";
        String markRoom    = "UPDATE rooms SET status = 'booked' WHERE room_id = ?";

        try (Connection con = DBUtil.getConnection()) {
            con.setAutoCommit(false);

            // 1. insert booking
            int bookingId = -1;
            try (PreparedStatement ps = con.prepareStatement(insertBooking, PreparedStatement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, booking.getUserId());
                ps.setInt(2, booking.getRoomId());
                ps.setDate(3, new Date(booking.getCheckIn().getTime()));
                ps.setDate(4, new Date(booking.getCheckOut().getTime()));
                ps.setInt(5, booking.getGuests());
                ps.setDouble(6, booking.getTotalAmount());
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) bookingId = rs.getInt(1);
                }
            }
            if (bookingId == -1) throw new SQLException("No booking id generated");

            // 2. insert payment
            try (PreparedStatement ps = con.prepareStatement(insertPayment)) {
                ps.setInt(1, bookingId);
                ps.setDouble(2, booking.getTotalAmount());
                ps.setString(3, paymentMethod);
                ps.executeUpdate();
            }

            // 3. mark room booked
            try (PreparedStatement ps = con.prepareStatement(markRoom)) {
                ps.setInt(1, booking.getRoomId());
                ps.executeUpdate();
            }

            con.commit();
            return bookingId;
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        }
    }

    // Bookings for one user including room info (JOIN)
    public List<Booking> getBookingsByUser(int userId) {
        List<Booking> list = new ArrayList<>();
        String sql = "SELECT b.*, r.room_number, r.room_type FROM bookings b " +
                     "JOIN rooms r ON b.room_id = r.room_id " +
                     "WHERE b.user_id = ? ORDER BY b.booking_date DESC";
        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    private Booking mapRow(ResultSet rs) throws SQLException {
        Booking b = new Booking();
        b.setBookingId(rs.getInt("booking_id"));
        b.setUserId(rs.getInt("user_id"));
        b.setRoomId(rs.getInt("room_id"));
        b.setCheckIn(rs.getDate("check_in"));
        b.setCheckOut(rs.getDate("check_out"));
        b.setGuests(rs.getInt("guests"));
        b.setTotalAmount(rs.getDouble("total_amount"));
        b.setBookingStatus(rs.getString("booking_status"));
        try { b.setRoomNumber(rs.getString("room_number")); } catch (SQLException ignored) {}
        try { b.setRoomType(rs.getString("room_type")); } catch (SQLException ignored) {}
        return b;
    }
}