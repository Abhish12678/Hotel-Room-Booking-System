package com.hotel.servlet;

import com.hotel.dao.BookingDAO;
import com.hotel.dao.RoomDAO;
import com.hotel.model.Booking;
import com.hotel.model.Room;
import com.hotel.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

@WebServlet("/processBooking")
public class ProcessBookingServlet extends HttpServlet {
    private BookingDAO bookingDAO = new BookingDAO();
    private RoomDAO roomDAO = new RoomDAO();

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        User user = session == null ? null : (User) session.getAttribute("user");
        if (user == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int roomId = Integer.parseInt(request.getParameter("roomId"));
        String checkInStr = request.getParameter("checkIn");
        String checkOutStr = request.getParameter("checkOut");
        int guests = Integer.parseInt(request.getParameter("guests"));
        String paymentMethod = request.getParameter("paymentMethod");

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date checkIn, checkOut;
        try {
            checkIn = sdf.parse(checkInStr);
            checkOut = sdf.parse(checkOutStr);
        } catch (ParseException e) {
            request.setAttribute("error", "Invalid dates.");
            request.getRequestDispatcher("book.jsp").forward(request, response);
            return;
        }

        if (!checkOut.after(checkIn)) {
            request.setAttribute("error", "Check-out must be after check-in.");
            request.setAttribute("room", roomDAO.getRoomById(roomId));
            request.getRequestDispatcher("book.jsp").forward(request, response);
            return;
        }

        Room room = roomDAO.getRoomById(roomId);
        long nights = TimeUnit.DAYS.convert(checkOut.getTime() - checkIn.getTime(), TimeUnit.MILLISECONDS);
        double total = nights * room.getPricePerNight();

        Booking booking = new Booking(user.getUserId(), roomId, checkIn, checkOut, guests, total, "confirmed");
        int bookingId = bookingDAO.createBooking(booking, paymentMethod);

        if (bookingId == -1) {
            request.setAttribute("error", "Booking failed. Room may have just been booked.");
            request.setAttribute("room", room);
            request.getRequestDispatcher("book.jsp").forward(request, response);
            return;
        }

        request.setAttribute("bookingId", bookingId);
        request.setAttribute("room", room);
        request.setAttribute("checkIn", checkInStr);
        request.setAttribute("checkOut", checkOutStr);
        request.setAttribute("guests", guests);
        request.setAttribute("total", total);
        request.setAttribute("paymentMethod", paymentMethod);
        request.getRequestDispatcher("confirmation.jsp").forward(request, response);
    }
}