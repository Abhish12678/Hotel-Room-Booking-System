package com.hotel.servlet;

import com.hotel.dao.RoomDAO;
import com.hotel.model.Room;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/book")
public class BookServlet extends HttpServlet {
    private RoomDAO roomDAO = new RoomDAO();

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int roomId = Integer.parseInt(request.getParameter("roomId"));
        Room room = roomDAO.getRoomById(roomId);
        if (room == null || "booked".equals(room.getStatus())) {
            response.sendRedirect("rooms?error=Room is not available");
            return;
        }
        request.setAttribute("room", room);
        request.getRequestDispatcher("book.jsp").forward(request, response);
    }
}