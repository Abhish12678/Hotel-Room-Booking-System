-- =====================================================
--  Hotel Room Booking System - Database Setup
--  Run this with:  mysql -u root -p
--  Then inside mysql:  SOURCE database/hotel_booking.sql;
-- =====================================================

DROP DATABASE IF EXISTS hotel_booking;
CREATE DATABASE hotel_booking;
USE hotel_booking;

-- ---------- users ----------
CREATE TABLE users (
  user_id    INT AUTO_INCREMENT PRIMARY KEY,
  name       VARCHAR(100) NOT NULL,
  email      VARCHAR(100) NOT NULL UNIQUE,
  password   VARCHAR(255) NOT NULL,
  phone      VARCHAR(15),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------- rooms ----------
CREATE TABLE rooms (
  room_id        INT AUTO_INCREMENT PRIMARY KEY,
  room_number    VARCHAR(10) NOT NULL UNIQUE,
  room_type      VARCHAR(50)  NOT NULL,
  price_per_night DECIMAL(10,2) NOT NULL,
  capacity       INT NOT NULL,
  description    VARCHAR(255),
  status         ENUM('available','booked') DEFAULT 'available'
);

-- ---------- bookings ----------
CREATE TABLE bookings (
  booking_id    INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT NOT NULL,
  room_id       INT NOT NULL,
  check_in      DATE NOT NULL,
  check_out     DATE NOT NULL,
  guests        INT NOT NULL,
  total_amount  DECIMAL(10,2) NOT NULL,
  booking_status ENUM('confirmed','cancelled') DEFAULT 'confirmed',
  booking_date  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id),
  FOREIGN KEY (room_id) REFERENCES rooms(room_id)
);

-- ---------- payments ----------
CREATE TABLE payments (
  payment_id     INT AUTO_INCREMENT PRIMARY KEY,
  booking_id     INT NOT NULL,
  amount         DECIMAL(10,2) NOT NULL,
  payment_method ENUM('card','upi','cash') NOT NULL,
  payment_status ENUM('paid','pending','failed') DEFAULT 'pending',
  payment_date   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (booking_id) REFERENCES bookings(booking_id)
);

-- ---------- sample rooms ----------
INSERT INTO rooms (room_number, room_type, price_per_night, capacity, description, status) VALUES
('101', 'Single',  1500.00, 1, 'Single bed, AC, free WiFi',   'available'),
('102', 'Double',  2500.00, 2, 'Double bed, AC, TV, WiFi',    'available'),
('201', 'Deluxe',  4000.00, 3, 'King bed, mini bar, balcony', 'available'),
('202', 'Deluxe',  4000.00, 3, 'King bed, mini bar, balcony', 'available'),
('301', 'Suite',   7000.00, 4, 'Living room, kitchen, 2 TVs', 'available');

-- ---------- test data (optional) ----------
-- INSERT INTO users (name, email, password, phone) VALUES
-- ('Test User', 'test@example.com', 'test123', '9876543210');
--
-- SELECT * FROM rooms;
-- SELECT * FROM users;
-- SELECT b.booking_id, u.name, r.room_number, r.room_type,
--        b.check_in, b.check_out, b.total_amount, b.booking_status
-- FROM bookings b
-- JOIN users u ON b.user_id = u.user_id
-- JOIN rooms r ON b.room_id = r.room_id;