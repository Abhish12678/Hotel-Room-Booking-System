#!/bin/bash
# Downloads the MySQL JDBC connector into WebContent/WEB-INF/lib

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
WEBLIB="$PROJECT_DIR/WebContent/WEB-INF/lib"
mkdir -p "$WEBLIB"

cd "$WEBLIB"
if ls mysql-connector*.jar >/dev/null 2>&1; then
    echo "Connector already present:"
    ls mysql-connector*.jar
    exit 0
fi

echo "Downloading MySQL Connector/J 8.4.0..."
curl -fSL -o mysql-connector-j-8.4.0.jar \
  "https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.4.0/mysql-connector-j-8.4.0.jar" \
  --connect-timeout 30 -m 120 && echo "Downloaded OK:" && ls -la mysql-connector*.jar